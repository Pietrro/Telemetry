#pragma once
#include <cstdint>


void convert(float x, uint8_t* data);
