#include <Arduino.h>
#include "ArduinoLog.h"
#include "adcObj/adcObj.hpp"
#include "driver/can.h"
#include <TinyGPS++.h>
#include "Aditional/aditional.hpp"
#include <HardwareSerial.h>
#include <Arduino.h>
//#include "MPU6050/MPU6050.h"
#include "MPU9250/MPU9250c.hpp"


#define TX_GPIO_NUM   GPIO_NUM_14 //inversate??
#define RX_GPIO_NUM   GPIO_NUM_27
#define LOG_LEVEL LOG_LEVEL_ERROR
#define GPS_BAUDRATE 9600 
#define SHIFT_UP_PIN  33   
#define SHIFT_DOWN_PIN 34 

MPU9250c MPU;
u_int16_t status;
adcObj steeringAngle(ADC1_CHANNEL_7);
adcObj damper_left(ADC1_CHANNEL_4);
adcObj damper_right(ADC1_CHANNEL_5);

double latitude = 0;
double longitude = 0;
double speed = 0;

TinyGPSPlus gps;

twai_message_t tx_msg_mpu;
twai_message_t tx_msg_gps;
twai_message_t tx_msg_adc;
twai_message_t tx_msg_shift;
twai_message_t tx_msg_damp;
twai_message_t tx_msg_gyro;
twai_message_t tx_msg_acc;
twai_message_t tx_msg_steerang;

static const can_general_config_t g_config = {
  .mode = TWAI_MODE_NO_ACK,
  .tx_io = TX_GPIO_NUM,
  .rx_io = RX_GPIO_NUM,
  .clkout_io = TWAI_IO_UNUSED,
  .bus_off_io = TWAI_IO_UNUSED,
  .tx_queue_len = 1000,
  .rx_queue_len = 5,
  .alerts_enabled = TWAI_ALERT_ALL,
  .clkout_divider = 0,
  .intr_flags = ESP_INTR_FLAG_LEVEL1
};

static const can_timing_config_t t_config = CAN_TIMING_CONFIG_500KBITS();
static const can_filter_config_t f_config = CAN_FILTER_CONFIG_ACCEPT_ALL();


void setup() {
  delay(2000);
  Serial.begin(9600);
  Serial2.begin(GPS_BAUDRATE);
  Log.begin(LOG_LEVEL, &Serial);
  
  MPU.read();
  pinMode(SHIFT_UP_PIN, INPUT_PULLUP);  // Shift Up button
  pinMode(SHIFT_DOWN_PIN, INPUT_PULLUP); // Shift Down button



  status = can_driver_install(&g_config, &t_config, &f_config);
  if (status == ESP_OK) {
    Log.noticeln("Can driver installed");
  } else {
    Log.errorln("Can driver installation failed with error: %s", esp_err_to_name(status));
  }

  status = can_start();
  if (status == ESP_OK) {
    Log.noticeln("Can started");
  } else {
    Log.errorln("Can starting procedure failed with error: %s", esp_err_to_name(status));
  }

  // Inițializare mesaje CAN
  tx_msg_mpu.data_length_code = 8;
  tx_msg_mpu.identifier = 0x114;
  tx_msg_mpu.flags = CAN_MSG_FLAG_NONE;

  tx_msg_adc.data_length_code = 8;
  tx_msg_adc.identifier = 0x115;
  tx_msg_adc.flags = CAN_MSG_FLAG_NONE;

  tx_msg_gps.data_length_code = 8;
  tx_msg_gps.identifier = 0x116;
  tx_msg_gps.flags = CAN_MSG_FLAG_NONE;

  tx_msg_shift.data_length_code = 2;  
  tx_msg_shift.identifier = 0x117;    
  tx_msg_shift.flags = CAN_MSG_FLAG_NONE;

  tx_msg_damp.data_length_code = 8;  
  tx_msg_damp.identifier = 0x118;    
  tx_msg_damp.flags = CAN_MSG_FLAG_NONE;

  tx_msg_acc.data_length_code=6;
  tx_msg_acc.identifier=0x119;
  tx_msg_acc.flags=CAN_MSG_FLAG_NONE;

  tx_msg_gyro.data_length_code=6;
  tx_msg_gyro.identifier=0x120;
  tx_msg_gyro.flags=CAN_MSG_FLAG_NONE;

  tx_msg_steerang.data_length_code=6;
  tx_msg_steerang.identifier=0x121;
  tx_msg_steerang.flags=CAN_MSG_FLAG_NONE;
}

void loop() {
  
  int shiftUp = digitalRead(SHIFT_UP_PIN) == LOW;  
  int shiftDown = digitalRead(SHIFT_DOWN_PIN) == LOW;

 
  Serial.print("Shift Up: ");
  Serial.println(shiftUp ? "Pressed" : "Not Pressed");
  Serial.print("Shift Down: ");
  Serial.println(shiftDown ? "Pressed" : "Not Pressed");

  tx_msg_shift.data[0] = shiftUp ? 1 : 0;  // 1 pentru Shift Up, 0 nmc
  tx_msg_shift.data[1] = shiftDown ? 1 : 0;  // 1 pentru Shift Down, 0 nmc

  int dleft = damper_left.getVoltage();
  int dright = damper_right.getVoltage();
  int dsteeringAngle = steeringAngle.getVoltage();

  tx_msg_damp.data[0]=dleft/100;
  tx_msg_damp.data[1]=dleft%100;
  tx_msg_damp.data[2]=dright/100;  
  tx_msg_damp.data[3]=dright%100; 
  tx_msg_damp.data[4]=dsteeringAngle/100;
  tx_msg_damp.data[5]=dsteeringAngle%100; 

  status = can_transmit(&tx_msg_shift, pdMS_TO_TICKS(1000));
  if (status == ESP_OK) {
    //Log.noticeln("Can message SHIFT sent");
  } else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if (status == ESP_OK) Log.errorln("Can driver restarted");
  }

  float roll = MPU.getRoll();
  float pitch = MPU.getPitch();
  float yaw = MPU.getYaw();

tx_msg_mpu.data[6]=0;
  if(roll >= 0) {
    convert(roll, tx_msg_mpu.data);

  }
  else {
    convert(roll*-1, tx_msg_mpu.data);
    tx_msg_mpu.data[6]= tx_msg_mpu.data[6]+1; 
  }

  if(pitch >= 0) {
    convert(pitch, tx_msg_mpu.data+2);
  }
  else {
    convert(pitch*-1, tx_msg_mpu.data+2);
    tx_msg_mpu.data[6]= tx_msg_mpu.data[6]+2; 
  }

  if(yaw >= 0) {
    convert(yaw, tx_msg_mpu.data+4);
  }
  else {
    convert(yaw*-1, tx_msg_mpu.data+4);
    tx_msg_mpu.data[6]= tx_msg_mpu.data[6]+4; 
  }


  float gx = MPU.currentData.gyroX;
  float gy = MPU.currentData.gyroY; 
  float gz = MPU.currentData.gyroZ;
  convert(gx, tx_msg_gyro.data);
  convert(gy, tx_msg_gyro.data+2);
  convert(gz, tx_msg_gyro.data+4);

  float ax = MPU.currentData.accelX;
  float ay = MPU.currentData.accelY; 
  float az = MPU.currentData.accelZ;
  convert(ax, tx_msg_acc.data);
  convert(ay, tx_msg_acc.data+2);
  convert(az, tx_msg_acc.data+4);

  convert(MPU.currentData.accelX, tx_msg_acc.data);
  convert(MPU.currentData.accelY, tx_msg_acc.data+2);
  convert(MPU.currentData.accelZ, tx_msg_acc.data+4);

  //gyro
  convert(MPU.currentData.gyroX, tx_msg_gyro.data);
  convert(MPU.currentData.gyroY, tx_msg_gyro.data+2);
  convert(MPU.currentData.gyroZ, tx_msg_gyro.data+4);


  if (Serial2.available() > 0) {
    if (gps.encode(Serial2.read())) {
      if (gps.location.isValid()) {
        latitude = gps.location.lat();
        longitude = gps.location.lng();
      }
      if (gps.speed.isValid()) {
        speed = gps.speed.kmph();
      }
    }
  }

  Serial.print("Latitude: ");
  Serial.println(latitude, 6);
  Serial.print("Longitude: ");
  Serial.println(longitude, 6);
  Serial.print("Speed: ");
  Serial.println(speed);

  //convert(fractional(latitude), tx_msg_gps.data);
 // convert(fractional(longitude), tx_msg_gps.data + 3);
  tx_msg_gps.data[7] = uint8_t(speed);

  status = can_transmit(&tx_msg_gps, pdMS_TO_TICKS(1000));
  if (status == ESP_OK) {
  } else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if (status == ESP_OK) Log.errorln("Can driver restarted");
  }

 

  status = can_transmit(&tx_msg_adc, pdMS_TO_TICKS(1000));
  if (status == ESP_OK) {
    //Log.noticeln("Can message ADC sent");
  } else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if (status == ESP_OK) Log.errorln("Can driver restarted");
  }
status = can_transmit(&tx_msg_mpu, pdMS_TO_TICKS(1000));
   if(status==ESP_OK) {
    Log.noticeln("Can message sent");
  }
  else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if(status==ESP_OK) Log.error("Can driver restarted");
  }

  status = can_transmit(&tx_msg_acc, pdMS_TO_TICKS(1000));
   if(status==ESP_OK) {
    Log.noticeln("Can message sent");
  }
  else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if(status==ESP_OK) Log.error("Can driver restarted");
  }

  status = can_transmit(&tx_msg_gyro, pdMS_TO_TICKS(1000));
   if(status==ESP_OK) {
    Log.noticeln("Can message sent");
  }
  else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if(status==ESP_OK) Log.error("Can driver restarted");
  }
  
  status = can_transmit(&tx_msg_damp, pdMS_TO_TICKS(1000));
  if(status==ESP_OK) {
    Log.noticeln("Can message sent");
  }
  else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if(status==ESP_OK) Log.errorln("Can driver restarted");
  }

  status = can_transmit(&tx_msg_shift, pdMS_TO_TICKS(1000));
  if(status==ESP_OK) {
    Log.noticeln("Can message sent");
  }
  else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if(status==ESP_OK) Log.errorln("Can driver restarted");
  }
  status = can_transmit(&tx_msg_steerang, pdMS_TO_TICKS(1000));
  if(status==ESP_OK) {
    Log.noticeln("Can message sent");
  }
  else {
    Log.errorln("Can message sending failed with error code: %s ;\nRestarting CAN driver", esp_err_to_name(status));
    can_stop();
    can_driver_uninstall();
    can_driver_install(&g_config, &t_config, &f_config);
    status = can_start();
    if(status==ESP_OK) Log.errorln("Can driver restarted");
  }
  delay(100);  
}