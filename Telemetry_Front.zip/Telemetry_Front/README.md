# TuIasiRacing Module 1
Module 1 of TuIasiRacing telemetry system. The system consists of a ESP32, a MPU6050 module used for angle and acceleration changes and 4 damper position sensors . All the data read is sent to a central unit via a CAN network.
